package model.ArrayList_Collect;

import java.sql.Time;
import java.util.Date;

public class OMMG_RAP_CHECK {

    private int GRADE_ID;
    private String RESTAURANT_NAME;
    private String EAT_DATE;
    private String EAT_TIME;

    public int getGRADE_ID() {
        return GRADE_ID;
    }

    public void setGRADE_ID(int GRADE_ID) {
        this.GRADE_ID = GRADE_ID;
    }

    public String getRESTAURANT_NAME() {
        return RESTAURANT_NAME;
    }

    public void setRESTAURANT_NAME(String RESTAURANT_NAME) {
        this.RESTAURANT_NAME = RESTAURANT_NAME;
    }

    public String getEAT_DATE() {
        return EAT_DATE;
    }

    public void setEAT_DATE(String EAT_DATE) {
        this.EAT_DATE = EAT_DATE;
    }

    public String getEAT_TIME() {
        return EAT_TIME;
    }

    public void setEAT_TIME(String EAT_TIME) {
        this.EAT_TIME = EAT_TIME;
    }

    public int getGRADE() {
        return GRADE;
    }

    public void setGRADE(int GRADE) {
        this.GRADE = GRADE;
    }

    private int GRADE;
}
