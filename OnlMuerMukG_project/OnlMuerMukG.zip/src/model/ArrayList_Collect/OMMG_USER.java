package model.ArrayList_Collect;

public class OMMG_USER {

    private int user_id;
    private String login_id;
    private double latitude_user;
    private double  hardness_user;

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public String getLogin_id() {
        return login_id;
    }

    public void setLogin_id(String login_id) {
        this.login_id = login_id;
    }

    public double getLatitude_user() {
        return latitude_user;
    }

    public void setLatitude_user(double latitude_user) {
        this.latitude_user = latitude_user;
    }

    public double getHardness_user() {
        return hardness_user;
    }

    public void setHardness_user(double hardness_user) {
        this.hardness_user = hardness_user;
    }
}
