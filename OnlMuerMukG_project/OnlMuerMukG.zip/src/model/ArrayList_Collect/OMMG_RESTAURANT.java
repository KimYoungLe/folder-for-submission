package model.ArrayList_Collect;

public class OMMG_RESTAURANT {
    private int restraurant_id;
    private String owner_id;
    private String restaurant_name;
    private double latitude;
    private double hardness;
    private String restaurant_category;
    private String signature_food;

    public int getRestraurant_id() {
        return restraurant_id;
    }

    public void setRestraurant_id(int restraurant_id) {
        this.restraurant_id = restraurant_id;
    }

    public String getOwner_id() {
        return owner_id;
    }

    public void setOwner_id(String owner_id) {
        this.owner_id = owner_id;
    }

    public String getRestaurant_name() {
        return restaurant_name;
    }

    public void setRestaurant_name(String restaurant_name) {
        this.restaurant_name = restaurant_name;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getHardness() {
        return hardness;
    }

    public void setHardness(double hardness) {
        this.hardness = hardness;
    }

    public String getRestaurant_category() {
        return restaurant_category;
    }

    public void setRestaurant_category(String restaurant_category) {
        this.restaurant_category = restaurant_category;
    }

    public String getSignature_food() {
        return signature_food;
    }

    public void setSignature_food(String signature_food) {
        this.signature_food = signature_food;
    }
}
