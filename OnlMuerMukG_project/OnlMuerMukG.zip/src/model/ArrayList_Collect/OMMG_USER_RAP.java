package model.ArrayList_Collect;

public class OMMG_USER_RAP {
    private int user_id;
    private int restaurant_id;
    private String eat_date;
    private String eat_time;
    private int grade;

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public int getRestaurant_id() {
        return restaurant_id;
    }

    public void setRestaurant_id(int restaurant_id) {
        this.restaurant_id = restaurant_id;
    }

    public String getEat_date() {
        return eat_date;
    }

    public void setEat_date(String eat_date) {
        this.eat_date = eat_date;
    }

    public String getEat_time() {
        return eat_time;
    }

    public void setEat_time(String eat_time) {
        this.eat_time = eat_time;
    }

    public int getGrade() {
        return grade;
    }

    public void setGrade(int grade) {
        this.grade = grade;
    }
}
