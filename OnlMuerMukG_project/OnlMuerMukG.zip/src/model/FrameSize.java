package model;

public interface FrameSize {

    int FrameWidth = 650;
    int FrameHeight = 1050;
    int BlankWidth = 100;
    int BlankHeight = 45;
    int ButtonWidth = 150;
    int ButtonHeight = 60;
    int TxtWidth= 25;
    int TxtHeight=40;

}
