package com.pettaming;

public class PetTamingException extends Exception {
	
	public PetTamingException(String message) {
		super(message);
	}

}
