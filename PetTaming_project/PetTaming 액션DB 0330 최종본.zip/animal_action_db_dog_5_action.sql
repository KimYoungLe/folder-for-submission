-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: animal_action_db
-- ------------------------------------------------------
-- Server version	8.0.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dog_5_action`
--

DROP TABLE IF EXISTS `dog_5_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dog_5_action` (
  `Y` int(11) NOT NULL AUTO_INCREMENT,
  `x0` varchar(30) DEFAULT NULL,
  `x1` varchar(30) DEFAULT NULL,
  `x2` varchar(30) DEFAULT NULL,
  `x3` varchar(30) DEFAULT NULL,
  `x4` varchar(30) DEFAULT NULL,
  `x5` varchar(30) DEFAULT NULL,
  `x6` varchar(30) DEFAULT NULL,
  `x7` varchar(30) DEFAULT NULL,
  `x8` varchar(30) DEFAULT NULL,
  `x9` varchar(30) DEFAULT NULL,
  `x10` varchar(30) DEFAULT NULL,
  `x11` varchar(30) DEFAULT NULL,
  `x12` varchar(30) DEFAULT NULL,
  `x13` varchar(30) DEFAULT NULL,
  `x14` varchar(30) DEFAULT NULL,
  `x15` varchar(30) DEFAULT NULL,
  `x16` varchar(30) DEFAULT NULL,
  `x17` varchar(30) DEFAULT NULL,
  `x18` varchar(30) DEFAULT NULL,
  `x19` varchar(30) DEFAULT NULL,
  `x20` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`Y`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dog_5_action`
--

LOCK TABLES `dog_5_action` WRITE;
/*!40000 ALTER TABLE `dog_5_action` DISABLE KEYS */;
INSERT INTO `dog_5_action` VALUES (1,'color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_2'),(2,'color_2','White','White','White','White','White','White','White','White','White','White','White','White','White','White','color_border','color_border','White','White','White','color_2'),(3,'color_2','White','White','White','White','White','White','White','White','White','White','White','White','White','color_border','color_1','color_1','color_border','White','White','color_2'),(4,'color_2','White','White','White','White','White','White','White','White','White','White','White','White','White','color_border','color_1','color_1','color_2','color_border','White','color_2'),(5,'color_2','White','White','White','White','White','White','White','White','White','White','White','White','White','White','color_border','color_2','color_2','color_2','color_border','color_2'),(6,'color_2','White','White','White','White','White','White','White','White','White','White','White','White','White','White','White','color_border','color_2','color_2','color_border','color_2'),(7,'color_2','White','White','White','color_border','White','White','White','color_border','color_border','White','White','White','White','White','White','color_border','color_2','color_2','color_border','color_2'),(8,'color_2','White','White','color_border','color_2','color_border','color_border','color_border','color_2','color_2','color_border','White','White','White','White','White','color_border','color_2','color_2','color_border','color_2'),(9,'color_2','White','color_border','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_border','White','White','White','White','color_border','color_2','color_2','color_border','color_2'),(10,'color_2','color_border','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_border','White','White','White','color_border','color_2','color_2','color_border','color_2'),(11,'color_2','color_border','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_border','color_border','color_border','color_border','color_2','color_2','color_2','color_border','color_2'),(12,'color_2','color_border','color_2','color_border','color_2','color_2','color_2','color_2','color_2','color_2','color_border','color_2','color_border','color_2','color_2','color_2','color_2','color_2','color_2','color_border','color_2'),(13,'color_2','color_border','color_2','color_border','color_2','color_border','color_2','color_border','color_2','color_2','color_border','color_2','color_border','color_2','color_2','color_2','color_2','color_2','color_2','color_border','color_2'),(14,'color_2','color_border','color_1','color_border','color_2','color_border','color_2','color_border','color_2','color_2','color_border','color_1','color_border','color_2','color_2','color_2','color_2','color_2','color_border','White','color_2'),(15,'color_2','White','color_border','color_border','color_2','color_2','color_2','color_2','color_2','color_2','color_border','color_border','color_2','color_2','color_2','color_2','color_2','color_border','White','White','color_2'),(16,'color_2','White','White','color_border','color_border','color_border','color_border','color_border','color_border','color_border','color_border','color_border','color_border','color_2','color_border','color_2','color_border','White','White','White','color_2'),(17,'color_2','White','color_border','color_1','color_1','color_1','color_1','color_1','color_1','color_1','color_border','White','color_border','color_2','color_border','color_2','color_border','White','White','White','color_2'),(18,'color_2','color_border','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_border','color_border','color_1','color_border','color_1','color_border','White','White','White','color_2'),(19,'color_2','color_border','color_border','color_border','color_border','color_border','color_border','color_border','color_border','color_border','color_border','color_border','color_border','color_border','color_border','color_border','color_border','White','White','White','color_2'),(20,'color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_2','color_2');
/*!40000 ALTER TABLE `dog_5_action` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-03-30 10:29:50
